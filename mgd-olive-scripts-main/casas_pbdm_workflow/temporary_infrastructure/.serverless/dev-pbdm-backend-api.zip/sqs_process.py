import boto3
import json
sqs = boto3.client('sqs')
queue_url = 'https://sqs.eu-west-1.amazonaws.com/722737779887/dev-mgd-ict-platform-workflow'

def process_message(message_body):
    print(f"processing message: {message_body}")
    # do what you want with the message here
    pass

if __name__ == "__main__":
    while True:
        messages = sqs.receive_message(
            QueueUrl=queue_url,
            MaxNumberOfMessages=1,
            MessageAttributeNames=[
                'All'
            ],
            VisibilityTimeout=0,
            WaitTimeSeconds=0
        )
        message = json.loads(messages['Messages'][0]['Body'])
        print(type(message))
        dataset = message['dataset']
        print(dataset)
        #process_message(message.body)
        message.delete()